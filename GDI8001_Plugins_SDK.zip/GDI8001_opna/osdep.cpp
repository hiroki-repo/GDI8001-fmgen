
//
//		OsDependent
//		BouKiCHi 2019
//		(OS依存のルーチンをまとめます)
//		onion software/onitama 2019/1
//

#include <stdio.h>
#include "osdep.h"

OsDependent::OsDependent(void)
{
}

OsDependent::~OsDependent(void)
{
}

