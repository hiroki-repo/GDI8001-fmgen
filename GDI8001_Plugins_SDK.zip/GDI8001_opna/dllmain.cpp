﻿// dllmain.cpp : DLL アプリケーションのエントリ ポイントを定義します。
#include "pch.h"
#include "../GDI8001.h"
#include "mucomvm.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

typeofpluginctx* archfromgdi8001;

mucomvm* GDIOPNA;


int uniquememaccess4fmg(int prm_0, int prm_1, int prm_2) {
    if (prm_2 == 4) { GDIOPNA->ResetFM(); GDIOPNA->StartINT3(); return 0; }
    switch (prm_2 & 3) {
    case 0:
        GDIOPNA->store(prm_0, prm_1);
        return 0;
        break;
    case 1:
        return GDIOPNA->load(prm_0);
        break;
    case 2:
        GDIOPNA->output(prm_0, prm_1);
        return 0;
        break;
    case 3:
        return GDIOPNA->input(prm_0);
        break;
    }
    return 0;
}

void __stdcall mtcode(void* prm_0) { while (true) { Sleep(1); GDIOPNA->UpdateTime(1024); } }

extern "C" __declspec(dllexport) void InitPlugin(typeofpluginctx* prm_0) {
    archfromgdi8001 = prm_0;
    GDIOPNA = new mucomvm;
    prm_0->uniquememaccess = uniquememaccess4fmg;
    GDIOPNA->SetOrignalMode();
    GDIOPNA->SetOption(0);
    GDIOPNA->InitSoundSystem(44100);
    prm_0->ispluginloaded = true;
    prm_0->plugintype[0] = 0x30000;
    GDIOPNA->StartINT3();
}