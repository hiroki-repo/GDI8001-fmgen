
//
//	MUCOM88 plugin manager
//
#ifndef __PLUGIN_h
#define __PLUGIN_h

#include "mucom88if.h"


#endif


